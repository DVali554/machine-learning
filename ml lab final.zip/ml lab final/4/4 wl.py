# --- Matrix & Utility Functions ---

def dot(A, B):
    BT = list(zip(*B))
    return [[sum(a * b for a, b in zip(row, col)) for col in BT] for row in A]

def add_mv(M, v):
    return [[x + v[j] for j, x in enumerate(row)] for row in M]

def mtranspose(M):
    return list(map(list, zip(*M)))

def sum_axis0(M):
    return [sum(col) for col in zip(*M)]

def apply_func(M, f):
    return [[f(x) for x in row] for row in M]

def sigmoid(x):
    if x < -100: return 0.0
    if x > 100: return 1.0
    return 1 / (1 + 2.718281828459045 ** (-x))

def sig_deriv(x): 
    return x * (1 - x)

seed_val = 42
def rand():
    global seed_val
    seed_val = (seed_val * 1664525 + 1013904223) % (2**32)
    return seed_val / (2**32)

# --- Data Loader ---

def load_data(filename):
    X, y = [], []
    lines = open(filename).readlines()
    start = 0
    try:
        float(lines[0].split(',')[0])
    except:
        start = 1
    for line in lines[start:]:
        parts = line.strip().split(',')
        if len(parts) < 8: continue
        try:
            y.append([float(parts[0])])
            X.append([float(x) for x in parts[1:8]])
        except:
            continue
    return X, y

# --- Weights & Training ---

def init_weights(i_size, h_size, o_size):
    W1 = [[rand() * 2 - 1 for _ in range(h_size)] for _ in range(i_size)]
    B1 = [[0] * h_size]
    W2 = [[rand() * 2 - 1 for _ in range(o_size)] for _ in range(h_size)]
    B2 = [[0] * o_size]
    return W1, B1, W2, B2

def train(X, y, h=4, epochs=5000, lr=0.01):
    i_size, o_size = len(X[0]), len(y[0])
    W1, B1, W2, B2 = init_weights(i_size, h, o_size)
    for e in range(epochs):
        Z1 = add_mv(dot(X, W1), B1[0])
        A1 = apply_func(Z1, sigmoid)
        Z2 = add_mv(dot(A1, W2), B2[0])
        A2 = apply_func(Z2, sigmoid)
        loss = sum((y[i][0] - A2[i][0])**2 for i in range(len(y))) / len(y)
        
        # Backpropagation
        dZ2 = [[(A2[i][j] - y[i][j]) * sig_deriv(A2[i][j]) for j in range(len(A2[0]))] 
                for i in range(len(A2))]
        dW2 = dot(mtranspose(A1), dZ2)
        dB2 = [sum_axis0(dZ2)]
        tmp = dot(dZ2, mtranspose(W2))
        dZ1 = [[tmp[i][j] * sig_deriv(A1[i][j]) for j in range(len(A1[0]))] 
                for i in range(len(A1))]
        dW1 = dot(mtranspose(X), dZ1)
        dB1 = [sum_axis0(dZ1)]
        
        # Update weights & biases
        W1 = [[W1[i][j] - lr * dW1[i][j] for j in range(len(W1[0]))] for i in range(len(W1))]
        B1 = [[B1[0][j] - lr * dB1[0][j] for j in range(len(B1[0]))]]
        W2 = [[W2[i][j] - lr * dW2[i][j] for j in range(len(W2[0]))] for i in range(len(W2))]
        B2 = [[B2[0][j] - lr * dB2[0][j] for j in range(len(B2[0]))]]
        
        if e % 500 == 0:
            print("Epoch", e, "Loss:", round(loss, 4))
    return W1, B1, W2, B2

def predict(X, W1, B1, W2, B2):
    Z1 = add_mv(dot(X, W1), B1[0])
    A1 = apply_func(Z1, sigmoid)
    Z2 = add_mv(dot(A1, W2), B2[0])
    return apply_func(Z2, sigmoid)

# --- Main ---

if __name__ == "__main__":
    X, y = load_data("traffic_accidents_dict new.csv")
    print("X shape:", (len(X), len(X[0]) if X else 0))
    print("y shape:", (len(y), len(y[0]) if y else 0))
    
    W1, B1, W2, B2 = train(X, y, h=5, epochs=3000, lr=0.001)
    preds = predict(X, W1, B1, W2, B2)
    print("\nSample Predictions (first 10):")
    for i in range(min(10, len(preds))):
        print("Predicted: {:.4f}, Actual: {}".format(preds[i][0], y[i][0]))
