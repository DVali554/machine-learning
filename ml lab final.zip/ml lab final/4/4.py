import numpy as np
import pandas as pd

def load_data(csv_file):
    data = pd.read_csv(csv_file).iloc[:, :8].dropna()
    return data.iloc[:, 1:].values, data.iloc[:, 0].values.reshape(-1, 1)

def sigmoid(x): 
    x = np.clip(x, -500, 500)  # Clip values to avoid overflow
    return 1 / (1 + np.exp(-x))


def train(X, y, h_size=4, epochs=5000, lr=0.01):
    W1, B1 = np.random.randn(X.shape[1], h_size), np.zeros((1, h_size))
    W2, B2 = np.random.randn(h_size, 1), np.zeros((1, 1))
    for _ in range(epochs):
        A1 = sigmoid(np.dot(X, W1) + B1)
        A2 = sigmoid(np.dot(A1, W2) + B2)
        loss = np.mean((y - A2) ** 2)
        dZ2 = (A2 - y) * A2 * (1 - A2)
        dZ1 = np.dot(dZ2, W2.T) * A1 * (1 - A1)
        W1 -= lr * np.dot(X.T, dZ1)
        B1 -= lr * np.sum(dZ1, axis=0)
        W2 -= lr * np.dot(A1.T, dZ2)
        B2 -= lr * np.sum(dZ2, axis=0)
    return W1, B1, W2, B2

def predict(X, W1, B1, W2, B2):
    return sigmoid(sigmoid(np.dot(X, W1) + B1).dot(W2) + B2)

if __name__ == "__main__":
    X, y = load_data("traffic_accidents_dict new.csv")
    W1, B1, W2, B2 = train(X, y, h_size=5, epochs=3000, lr=0.001)
    preds = predict(X, W1, B1, W2, B2)
    print("\nSample Predictions (first 10):")
    for i in range(10): print(f"Predicted: {preds[i][0]:.4f}, Actual: {y[i][0]}")
