def log2(x):
    count = 0
    while x < 1:
        x *= 2
        count -= 1
    while x >= 2:
        x /= 2
        count += 1
    return count

def entropy(data):
    labels = [row[-1] for row in data]
    total = len(labels)
    return -sum((labels.count(l) / total) * log2(labels.count(l) / total) for l in set(labels))

def best_attr(data):
    base = entropy(data)
    n = len(data[0]) - 1
    gains = []
    for i in range(n):
        vals = set(row[i] for row in data)
        e = 0
        for v in vals:
            subset = [r for r in data if r[i] == v]
            e += len(subset)/len(data) * entropy(subset)
        gains.append(base - e)
    return gains.index(max(gains))

def id3(data):
    labels = [row[-1] for row in data]
    if labels.count(labels[0]) == len(labels):
        return labels[0]
    attr = best_attr(data)
    tree = {attr: {}}
    for val in set(row[attr] for row in data):
        sub = [r[:attr]+r[attr+1:] for r in data if r[attr] == val]
        tree[attr][val] = id3(sub)
    return tree

def load_csv(filename):
    with open(filename) as f:
        lines = f.read().strip().split('\n')
        return [line.split(',') for line in lines][1:]

# Run
data = load_csv("car_price_dataset.csv")
print(id3(data))
