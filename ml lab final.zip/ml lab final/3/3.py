import pandas as pd
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.preprocessing import LabelEncoder

def id3_with_library(filename): 
    data = pd.read_csv(filename)

    # Encode all columns with LabelEncoder
    le = LabelEncoder()
    data = data.apply(le.fit_transform)

    X = data.iloc[:, :-1] 
    y = data.iloc[:, -1] 

    model = DecisionTreeClassifier(criterion="entropy") 
    model.fit(X, y) 

    print(export_text(model, feature_names=list(X.columns))) 

filename = "car_price_dataset.csv"  # Replace with actual file path 
id3_with_library(filename)
