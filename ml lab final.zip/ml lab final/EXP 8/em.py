import pandas as pd
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
import matplotlib.pyplot as plt

# Load dataset
data = pd.read_csv("Obesity prediction.csv")

# Use Height and Weight for clustering
X = data[['Height', 'Weight']]

# K-Means
kmeans = KMeans(n_clusters=3, random_state=0)
kmeans_labels = kmeans.fit_predict(X)

# EM Clustering (GMM)
gmm = GaussianMixture(n_components=3, random_state=0)
gmm_labels = gmm.fit_predict(X)

# Plot
plt.subplot(1, 2, 1)
plt.scatter(X['Height'], X['Weight'], c=kmeans_labels)
plt.title("K-Means Clustering")

plt.subplot(1, 2, 2)
plt.scatter(X['Height'], X['Weight'], c=gmm_labels)
plt.title("EM Clustering (GMM)")

plt.tight_layout()
plt.show()
