import csv, random, math

# Load data (Height, Weight)
def load_data(filename):
    with open(filename, 'r') as f:
        reader = csv.DictReader(f)
        return [[float(row['Height']), float(row['Weight'])] for row in reader]

# Euclidean distance
def dist(a, b):
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))

# K-Means
def kmeans(data, k=3, epochs=10):
    centroids = random.sample(data, k)
    for _ in range(epochs):
        clusters = [[] for _ in range(k)]
        for point in data:
            idx = min(range(k), key=lambda i: dist(point, centroids[i]))
            clusters[idx].append(point)
        for i in range(k):
            if clusters[i]:
                centroids[i] = [sum(x) / len(x) for x in zip(*clusters[i])]
    return clusters

# Expectation-Maximization (simplified GMM for 2D Gaussian)
def em(data, k=3, epochs=10):
    means = random.sample(data, k)
    variances = [[1.0, 1.0]] * k
    weights = [1/k] * k

    def gaussian(x, mean, var):
        prob = 1
        for xi, mi, vi in zip(x, mean, var):
            prob *= (1 / math.sqrt(2 * math.pi * vi)) * math.exp(-((xi - mi) ** 2) / (2 * vi))
        return prob

    for _ in range(epochs):
        responsibilities = [[0]*k for _ in data]
        for i, x in enumerate(data):
            total = sum(weights[j] * gaussian(x, means[j], variances[j]) for j in range(k))
            for j in range(k):
                responsibilities[i][j] = weights[j] * gaussian(x, means[j], variances[j]) / total

        for j in range(k):
            weight_sum = sum(r[j] for r in responsibilities)
            weights[j] = weight_sum / len(data)
            means[j] = [sum(data[i][d] * responsibilities[i][j] for i in range(len(data))) / weight_sum for d in range(2)]
            variances[j] = [
                sum(responsibilities[i][j] * (data[i][d] - means[j][d])**2 for i in range(len(data))) / weight_sum
                for d in range(2)
            ]
    return means

# Run
data = load_data("Obesity prediction.csv")
print("K-Means Cluster Centers:")
for c in kmeans(data):
    print([round(sum(x)/len(x), 2) for x in zip(*c)])

