def load_data(file_path):
    with open(file_path, "r") as file:
        lines = file.readlines()
    
    header = lines[0].strip().split(",")  
    data = [line.strip().split(",") for line in lines[1:]]
    
    return header, data

def encode_categorical(data):
    encoders = {}
    encoded_data = []

    for col in range(len(data[0])):  
        unique_values = list(set(row[col] for row in data))
        encoders[col] = {val: idx for idx, val in enumerate(unique_values)}  

    for row in data:
        encoded_data.append([encoders[col][row[col]] for col in range(len(row))])
    
    return encoded_data

def train_test_split_manual(data, test_size=0.2):
    split_idx = int(len(data) * (1 - test_size))
    train, test = data[:split_idx], data[split_idx:]
    
    X_train = [row[:-1] for row in train]
    y_train = [row[-1] for row in train]
    X_test = [row[:-1] for row in test]
    y_test = [row[-1] for row in test]
    
    return X_train, X_test, y_train, y_test

def calculate_probabilities(X_train, y_train):
    from collections import defaultdict
    import math

    class_counts = {}
    feature_counts = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))

    for i in range(len(y_train)):
        label = y_train[i]
        class_counts[label] = class_counts.get(label, 0) + 1
        
        for j in range(len(X_train[i])):
            feature_value = X_train[i][j]
            feature_counts[label][j][feature_value] += 1

    total_samples = len(y_train)
    class_probs = {label: count / total_samples for label, count in class_counts.items()}
    feature_probs = {}

    for label, features in feature_counts.items():
        feature_probs[label] = {}
        for feature_idx, values in features.items():
            feature_probs[label][feature_idx] = {
                val: (count + 1) / (class_counts[label] + len(values)) for val, count in values.items()
            }

    return class_probs, feature_probs

def predict(X_test, class_probs, feature_probs):
    import math

    predictions = []
    for row in X_test:
        class_scores = {}

        for label, class_prob in class_probs.items():
            score = math.log(class_prob)  # Start with prior probability
            for idx, feature_val in enumerate(row):
                score += math.log(feature_probs.get(label, {}).get(idx, {}).get(feature_val, 1e-6))  # Avoid log(0)
            
            class_scores[label] = score

        predicted_label = max(class_scores, key=class_scores.get)
        predictions.append(predicted_label)

    return predictions

def accuracy(y_test, y_pred):
    correct = sum(1 for i in range(len(y_test)) if y_test[i] == y_pred[i])
    return correct / len(y_test)

def classification_report_manual(y_test, y_pred):
    from collections import Counter

    labels = sorted(set(y_test))
    report = {label: {"TP": 0, "FP": 0, "FN": 0} for label in labels}

    for i in range(len(y_test)):
        actual, predicted = y_test[i], y_pred[i]
        if actual == predicted:
            report[actual]["TP"] += 1
        else:
            report[predicted]["FP"] += 1
            report[actual]["FN"] += 1

    print("\nClassification Report:")
    print("               precision    recall  f1-score   support")
    for label in labels:
        tp, fp, fn = report[label]["TP"], report[label]["FP"], report[label]["FN"]
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1 = (2 * precision * recall) / (precision + recall) if (precision + recall) > 0 else 0.0
        support = y_test.count(label)

        print(f"{label:<15}{precision:.2f}      {recall:.2f}      {f1:.2f}       {support}")

    overall_acc = accuracy(y_test, y_pred)
    print(f"\nAccuracy: {overall_acc:.2f}")

def main():
    file_path = "samsung_mobile_sales.csv"  

    header, data = load_data(file_path)
    encoded_data = encode_categorical(data)
    X_train, X_test, y_train, y_test = train_test_split_manual(encoded_data)

    class_probs, feature_probs = calculate_probabilities(X_train, y_train)

    y_pred = predict(X_test, class_probs, feature_probs)
    classification_report_manual(y_test, y_pred)

if __name__ == "__main__":
    main()
