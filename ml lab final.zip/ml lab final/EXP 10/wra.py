import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv("logistic.csv").dropna(subset=["age", "glucose"])
X, y = df["age"].values, df["glucose"].values

# LWR function
def locally_weighted_regression(X, y, x_query, tau):
    W = np.diag(np.exp(-((X - x_query) ** 2) / (2 * tau ** 2)))
    X_bias = np.c_[np.ones(len(X)), X]
    theta = np.linalg.pinv(X_bias.T @ W @ X_bias) @ X_bias.T @ W @ y
    return np.array([1, x_query]) @ theta

# Predictions & Plot
X_test = np.linspace(X.min(), X.max(), 100)
y_pred = np.array([locally_weighted_regression(X, y, x, 5) for x in X_test])

plt.scatter(X, y, color="blue", alpha=0.5, label="Data")
plt.plot(X_test, y_pred, "r-", label="LWR Fit")
plt.xlabel("Age"), plt.ylabel("Glucose Level"), plt.legend()
plt.title("Locally Weighted Regression (LWR)")
plt.show()
