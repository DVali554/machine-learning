def read_csv_manual(filename):
    """Read CSV manually and extract 'age' and 'glucose' columns."""
    X, y = [], []
    with open(filename, "r") as file:
        lines = file.readlines()
        headers = lines[0].strip().split(",")  # Extract column names
        
        # Find index of 'age' and 'glucose'
        age_index = headers.index("age")
        glucose_index = headers.index("glucose")
        
        # Read data
        for line in lines[1:]:  # Skip header
            values = line.strip().split(",")
            try:
                age = float(values[age_index])
                glucose = float(values[glucose_index])
                X.append(age)
                y.append(glucose)
            except ValueError:
                continue  # Skip non-numeric values
    return X, y

def exp_manual(x):
    """Manually compute exponential using Taylor series."""
    n_terms = 20  # Higher = more precision
    result = 1.0
    term = 1.0
    for i in range(1, n_terms):
        term *= x / i
        result += term
    return result

def gaussian_weight(x, x_query, tau):
    """Compute Gaussian weight manually."""
    weights = []
    for xi in x:
        diff = xi - x_query
        weights.append(exp_manual(-(diff * diff) / (2 * tau * tau)))
    return weights

def matrix_inverse(matrix):
    """Manually compute the inverse of a 2x2 matrix."""
    det = matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0]
    if det == 0:
        return None  # Singular matrix
    return [[matrix[1][1] / det, -matrix[0][1] / det],
            [-matrix[1][0] / det, matrix[0][0] / det]]

def locally_weighted_regression(X, y, x_query, tau):
    """Perform Locally Weighted Regression manually."""
    n = len(X)
    
    # Compute weights
    W = gaussian_weight(X, x_query, tau)
    
    # Compute weighted matrices
    X_bias = [[1, X[i]] for i in range(n)]  # Bias term
    XTWX = [[0, 0], [0, 0]]  # 2x2 matrix
    XTWY = [0, 0]  # 2x1 matrix

    for i in range(n):
        w = W[i]
        x1, x2 = X_bias[i]
        yi = y[i]
        
        XTWX[0][0] += w * x1 * x1
        XTWX[0][1] += w * x1 * x2
        XTWX[1][0] += w * x2 * x1
        XTWX[1][1] += w * x2 * x2
        
        XTWY[0] += w * x1 * yi
        XTWY[1] += w * x2 * yi

    # Compute (X'WX)^(-1)
    XTWX_inv = matrix_inverse(XTWX)
    if XTWX_inv is None:
        return None  # Avoid division by zero

    # Compute theta = (X'WX)^(-1) * (X'WY)
    theta0 = XTWX_inv[0][0] * XTWY[0] + XTWX_inv[0][1] * XTWY[1]
    theta1 = XTWX_inv[1][0] * XTWY[0] + XTWX_inv[1][1] * XTWY[1]

    # Compute prediction
    return theta0 + theta1 * x_query

# Load dataset manually
filename = "logistic.csv"
X, y = read_csv_manual(filename)

# Apply LWR for multiple query points
tau = 5  # Bandwidth parameter
X_test = [min(X) + i * (max(X) - min(X)) / 10 for i in range(11)]  # 10 test points
y_pred = [locally_weighted_regression(X, y, x, tau) for x in X_test]

# Print results
print("Predictions for different ages:")
for x, y in zip(X_test, y_pred):
    print(f"Age: {x:.2f}, Predicted Glucose: {y:.2f}")
