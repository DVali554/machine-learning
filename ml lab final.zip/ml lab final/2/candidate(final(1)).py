def read_csv(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
    header = lines[0].strip().split(',')
    data = [line.strip().split(',') for line in lines[1:]]
    return header, data

def candidate_elimination(data, target_index):
    num_attributes = len(data[0]) - 1  # Excluding target column
    specific_h = ['0'] * num_attributes
    general_h = [['?'] * num_attributes]

    for row in data:
        instance = row[:-1]  # Excluding target column
        label = row[target_index]

        if label == 'Laptop':  # Positive example
            for j in range(num_attributes):
                if specific_h[j] == '0':
                    specific_h[j] = instance[j]
                elif specific_h[j] != instance[j]:
                    specific_h[j] = '?'
            general_h = [h for h in general_h if all(h[k] == '?' or h[k] == instance[k] for k in range(num_attributes))]

        else:  # Negative example
            new_general_h = []
            for h in general_h:
                for j in range(num_attributes):
                    if h[j] == '?':
                        if specific_h[j] != '?':  # Ensure we don't create too many unnecessary hypotheses
                            new_h = h[:]
                            new_h[j] = specific_h[j]
                            new_general_h.append(new_h)
            general_h = new_general_h if new_general_h else general_h  # Avoid empty hypothesis set

    return specific_h, general_h

# Load dataset manually
file_path = 'Netflix Userbase.csv'
header, data = read_csv(file_path)

# Assume last column is target
target_index = len(header) - 1

# Run Candidate Elimination
specific_h, general_h = candidate_elimination(data, target_index)

print("Specific Hypothesis:", specific_h)
print("General Hypotheses:", general_h)
