import pandas as pd

def candidate_elimination(data, target):
    num_attributes = len(data.columns) - 1  # Excluding target column
    specific_h = ['0'] * num_attributes
    general_h = [['?'] * num_attributes]

    for i, row in data.iterrows():
        instance = row[:-1].tolist()
        label = row[target]

        if label == 'Laptop':  # Positive example
            for j in range(num_attributes):
                if specific_h[j] == '0':
                    specific_h[j] = instance[j]
                elif specific_h[j] != instance[j]:
                    specific_h[j] = '?'
            general_h = [h for h in general_h if all(h[k] == '?' or h[k] == instance[k] for k in range(num_attributes))]

        else:  # Negative example
            new_general_h = []
            for h in general_h:
                for j in range(num_attributes):
                    if h[j] == '?':
                        if specific_h[j] != '?':  # Ensure we don't create too many unnecessary hypotheses
                            new_h = h[:]
                            new_h[j] = specific_h[j]
                            new_general_h.append(new_h)
            general_h = new_general_h if new_general_h else general_h  # Avoid empty hypothesis set

    return specific_h, general_h

# Load dataset
data = pd.read_csv('Netflix Userbase.csv')

# Assume last but second column is target
target = data.columns[-1]

# Run Candidate Elimination
specific_h, general_h = candidate_elimination(data, target)

print("Specific Hypothesis:", specific_h)
print("General Hypotheses:", general_h)
