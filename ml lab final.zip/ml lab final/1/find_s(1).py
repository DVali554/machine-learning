def read_csv(filename):
    with open(filename, 'r') as file:
        data = [line.strip().split(',') for line in file]
    return data[1:], data[0]  

def find_s_algorithm(data):
    hypothesis = ['0'] * (len(data[0]) - 1)
    for row in data:
        if row[-1] == 'Education':  
            for j in range(len(hypothesis)):
                if hypothesis[j] == '0':  
                    hypothesis[j] = row[j]
                elif hypothesis[j] != row[j]:  
                    hypothesis[j] = '?'
    return hypothesis

def main():
    file_path = "phone_usage_india.csv"  
    try:
        data, header = read_csv(file_path)
        hypothesis = find_s_algorithm(data)
        print("\nMost Specific Hypothesis:", hypothesis)
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
