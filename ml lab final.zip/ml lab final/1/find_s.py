import pandas as pd
def find_s_algorithm(data):
    hypothesis = ['0'] * (len(data.columns) - 1)
    for i, row in data.iterrows():
        if row.iloc[-1] == 'Education':  
            for j in range(len(hypothesis)):
                if hypothesis[j] == '0':  
                    hypothesis[j] = row.iloc[j]
                elif hypothesis[j] != row.iloc[j]:  
                    hypothesis[j] = '?'
    return hypothesis
def main():
    file_path = "phone_usage_india.csv"  
    try:
        data = pd.read_csv(file_path)
        hypothesis = find_s_algorithm(data)
        print("\nMost Specific Hypothesis:", hypothesis)
    except Exception as e:
        print("Error:", e)
if __name__ == "__main__":
    main()
