df = []
with open("heart_disease.csv", "r") as file:
    headers = file.readline().strip().split(",")
    df = [[float(v) if v.replace('.', '', 1).isdigit() else None for v in line.strip().split(",")] for line in file]

target_index = headers.index("target")
feature_indices = {f: headers.index(f) for f in ["cp", "chol", "thalach", "exang"]}

for col in range(len(headers)):
    values = [row[col] for row in df if row[col] is not None]
    mean_value = sum(values) / len(values)
    for row in df:
        if row[col] is None:
            row[col] = mean_value

def discretize(values, bins=5):
    edges = [sorted(values)[int(len(values) * i / bins)] for i in range(bins)] + [max(values)]
    return [sum(v > e for e in edges) - 1 for v in values]

for col in range(len(headers)):
    if len(set(row[col] for row in df)) > 10:
        disc_vals = discretize([row[col] for row in df])
        for i in range(len(df)):
            df[i][col] = disc_vals[i]

def compute_probabilities(data, idx):
    counts = {row[idx]: 0 for row in data}
    for row in data: counts[row[idx]] += 1
    return {k: v / len(data) for k, v in counts.items()}

def compute_conditional_probabilities(data, f_idx, t_idx):
    cond, t_counts = {}, {}
    for row in data:
        f, t = row[f_idx], row[t_idx]
        t_counts[t] = t_counts.get(t, 0) + 1
        cond.setdefault(t, {}).setdefault(f, 0)
        cond[t][f] += 1
    return {t: {f: c / t_counts[t] for f, c in f_vals.items()} for t, f_vals in cond.items()}

target_probs = compute_probabilities(df, target_index)
feature_probs = {f: compute_conditional_probabilities(df, idx, target_index) for f, idx in feature_indices.items()}

def predict(evidence):
    probs = target_probs.copy()
    for f, v in evidence.items():
        if f in feature_probs:
            for t in probs:
                probs[t] *= feature_probs[f][t].get(v, 0.01)
    total = sum(probs.values())
    return {t: p / total for t, p in probs.items()} if total else "No data"
print("probability of no heart disease and probability of heart disease respectively:")
print(predict({"cp": 2, "chol": 2, "thalach": 2, "exang": 0}))
