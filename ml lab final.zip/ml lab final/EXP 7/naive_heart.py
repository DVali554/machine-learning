import pandas as pd
import numpy as np
from pgmpy.models import BayesianNetwork
from pgmpy.estimators import MaximumLikelihoodEstimator
from pgmpy.inference import VariableElimination

df = pd.read_csv("heart_disease.csv").apply(lambda x: pd.to_numeric(x, errors='coerce')).ffill()
df.columns = df.columns.str.strip()
df[df.columns] = df[df.columns].apply(lambda col: pd.qcut(col, q=5, labels=False, duplicates='drop') if col.nunique() > 10 else col)

df["target"] = df["target"].astype(int)

model = BayesianNetwork([("age", "chol"), ("sex", "chol"), ("chol", "target"), ("cp", "target"), ("thalach", "target"),
                         ("exang", "target"), ("oldpeak", "target"), ("slope", "target"), ("ca", "target"), ("thal", "target")])
model.fit(df, estimator=MaximumLikelihoodEstimator)

def predict_heart_disease(evidence):
    infer = VariableElimination(model)
    try:
        result = infer.query(variables=["target"], evidence=evidence)
        return result.values.tolist()
    except Exception as e:
        return f"Error: {e}"

print("probability of no heart disease and probability of heart disease respectively:")
print(predict_heart_disease({"cp": 2, "chol": 2, "thalach": 2, "exang": 0}))
