import numpy as np

# Euclidean distance function
def euclidean_distance(point1, point2):
    return np.sqrt(np.sum((point1 - point2) ** 2))

# k-NN classifier function
def knn(X_train, y_train, X_test, k):
    predictions = []
    for test_point in X_test:
        distances = []
        for i, train_point in enumerate(X_train):
            distance = euclidean_distance(test_point, train_point)
            distances.append((distance, y_train[i]))
        distances.sort(key=lambda x: x[0])  # Sort by distance
        nearest_neighbors = distances[:k]
        # Majority voting
        classes = [neighbor[1] for neighbor in nearest_neighbors]
        predicted_class = max(set(classes), key=classes.count)
        predictions.append(predicted_class)
    return predictions

# Iris dataset (using a small portion for simplicity)
# Features (sepal length, sepal width, petal length, petal width)
X = np.array([
    [5.1, 3.5, 1.4, 0.2], [4.9, 3.0, 1.4, 0.2], [4.7, 3.2, 1.3, 0.2], [4.6, 3.1, 1.5, 0.2],
    [5.0, 3.6, 1.4, 0.2], [5.4, 3.9, 1.7, 0.4], [4.6, 3.4, 1.4, 0.3], [5.0, 3.4, 1.5, 0.2],
    [4.4, 2.9, 1.4, 0.2], [4.9, 3.1, 1.5, 0.1]
])
y = np.array([0, 0, 0, 0, 0, 1, 1, 1, 1, 1])  # Class labels: 0 = Setosa, 1 = Versicolor

# Split data (Using first 8 for training and last 2 for testing)
X_train = X[:8]
y_train = y[:8]
X_test = X[8:]
y_test = y[8:]

# Use k=3 for k-NN
k = 3
predictions = knn(X_train, y_train, X_test, k)

# Print correct and wrong predictions
for i in range(len(y_test)):
    if y_test[i] == predictions[i]:
        print(f"Correct: Actual = {y_test[i]}, Predicted = {predictions[i]}")
    else:
        print(f"Wrong: Actual = {y_test[i]}, Predicted = {predictions[i]}")

