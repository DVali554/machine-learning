from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

# Load Iris dataset
iris = load_iris()
X = iris.data
y = iris.target

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Initialize KNeighborsClassifier with k=3
knn = KNeighborsClassifier(n_neighbors=3)

# Train the model
knn.fit(X_train, y_train)

# Predict on the test set
y_pred = knn.predict(X_test)

# Print correct and wrong predictions
for i in range(len(y_test)):
    if y_test[i] == y_pred[i]:
        print(f"Correct: Actual = {y_test[i]}, Predicted = {y_pred[i]}")
    else:
        print(f"Wrong: Actual = {y_test[i]}, Predicted = {y_pred[i]}")

# Optionally, print accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f"\nAccuracy: {accuracy * 100}%")
